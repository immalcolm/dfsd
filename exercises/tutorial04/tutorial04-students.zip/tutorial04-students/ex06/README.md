# Find the Largest Number in Each Row
Objective: Identify and print the largest number in each row of a 2D array.

Instructions:
Iterate through each row of the array.
For each row, find the largest number.
Print the largest number for each row.