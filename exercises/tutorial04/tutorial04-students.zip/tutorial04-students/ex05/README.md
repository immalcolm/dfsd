# Printing Diagonal Elements
Objective: Print elements on the diagonal of a square 2D array.

Instructions:
For a square matrix (n x n), print elements where the row index equals the column index.
Discuss how this would change if printing the secondary diagonal.