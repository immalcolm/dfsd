# Product Inventory Grid
Objective: Manage a small product inventory using a 2D array.

## Instructions
Create a 2D array to represent types of products in rows and their properties (name, price, quantity) in columns.
Update the inventory quantity for a product and print the updated inventory.