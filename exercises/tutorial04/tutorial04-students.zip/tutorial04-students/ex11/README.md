# Single Argument Arrow Function
Objective: Write an arrow function that takes one argument and returns the square of that number.

Instructions:
Create an arrow function named square that takes a single argument and returns its square.