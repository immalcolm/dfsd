# Classroom Seating Chart
Objective: Create and modify a 2D array to represent a classroom seating chart.

## Instructions
Initialize a 2D array representing seats in a classroom (5 rows by 4 columns).
Assign student names to each seat.
Change a student's seat and print the updated seating chart.