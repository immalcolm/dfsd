# Sum of All Elements in a 2D Array
Objective: Calculate and print the sum of all elements in a 2D array.

Instructions:
Use nested loops to iterate through the array and sum all the elements.