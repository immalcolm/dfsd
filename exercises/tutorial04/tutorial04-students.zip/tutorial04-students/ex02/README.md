# Initialize and Print a 2D Array
Objective: Learn to create and display a 2D array.

## Instructions:
Initialize a 2D array with specific values.
Write a nested loop to print each element in the format of its coordinates and value.