# Convert to Arrow Function
Objective: Convert a traditional function expression to an arrow function.

Instructions:
Convert the following traditional function into an arrow function:
```js
function add(a, b) {
    return a + b;
}

```