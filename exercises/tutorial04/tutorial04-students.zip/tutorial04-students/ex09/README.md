IIFE with Parameters
Objective: Pass parameters to an IIFE and use them inside the function to perform a calculation.

Instructions:
Write an IIFE that takes two numbers as parameters and logs their sum