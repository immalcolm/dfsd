# No Argument Arrow Function
Objective: Write an arrow function that returns a default greeting message.

Instructions:
Create an arrow function that takes no arguments and returns the string "Hello, World!".