# Initialize and Access a 2D Array
Objective: Learn to create, access, and modify elements in a 2D array.

Instructions:
Create a 2D array of integers.
Access and print the element at the second row and third column.
Change the value of this element and print the entire array.